import numpy as np

def sigmoid(x):
    # ---------------------------------------------------------
    # TODO: Implement the sigmoid activation function
    # Formula: f(x) = 1 / (1 + exp(-x))
    # ---------------------------------------------------------
    pass

def sigmoid_derivative(x):
    # ---------------------------------------------------------
    # TODO: Implement the derivative of the sigmoid function
    # Hint: It can be expressed using the sigmoid function itself: f(x) * (1 - f(x))
    # ---------------------------------------------------------
    pass

def run():
    # XOR dataset
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    Y = np.array([[0], [1], [1], [0]])

    # Initialize weights and biases deterministically for reproducible debugging
    np.random.seed(42)
    input_size = 2
    hidden_size = 2
    output_size = 1
    
    W1 = np.random.uniform(-1, 1, (input_size, hidden_size))
    b1 = np.zeros((1, hidden_size))
    W2 = np.random.uniform(-1, 1, (hidden_size, output_size))
    b2 = np.zeros((1, output_size))

    learning_rate = 0.5
    iterations = 5  # Start with 5 for the basic requirement. Increase later for exploration!

    print(f"{'Iter':<5} | {'Loss':<8} | {'Output (y_pred)':<30} | {'Target':<15} | {'W2 Mean':<10}")
    print("-" * 80)

    for i in range(iterations):
        # ---------------------------------------------------------
        # TODO: 1. FORWARD PASS
        # Calculate hidden layer output (h) and final prediction (y_pred)
        # Hint: h = sigmoid(X.dot(W1) + b1)
        # ---------------------------------------------------------
        y_pred = None 
        
        # Calculate Loss (Mean Squared Error)
        # loss = 0.5 * np.mean((y_pred - Y) ** 2)
        loss = 0.0 # Placeholder
        
        # ---------------------------------------------------------
        # TODO: 2. BACKWARD PASS (Chain Rule)
        # Calculate gradients: dW2, db2, dW1, db1
        # Error = 0.5 * (y_pred - Y)^2
        # Start with: d_Error/d_y_pred = (y_pred - Y) / number_of_samples
        # Then multiply by the derivative of the Sigmoid function.
        # ---------------------------------------------------------
        dW2 = np.zeros_like(W2) # Placeholder
        db2 = np.zeros_like(b2) # Placeholder
        dW1 = np.zeros_like(W1) # Placeholder
        db1 = np.zeros_like(b1) # Placeholder

        # ---------------------------------------------------------
        # TODO: 3. WEIGHT UPDATE
        # Update W1, b1, W2, b2 using the learning rate
        # Example: W2 -= learning_rate * dW2
        # ---------------------------------------------------------
        
        # Print tabular results for the report
        if y_pred is not None:
            pred_str = ", ".join([f"{val[0]:.4f}" for val in y_pred])
            target_str = ", ".join([str(val[0]) for val in Y])
            w2_mean = np.mean(W2)
            print(f"{i+1:<5} | {loss:<8.4f} | [{pred_str}] | [{target_str}] | {w2_mean:<10.4f}")

    # ---------------------------------------------------------
    # Output final parameters after all iterations
    # ---------------------------------------------------------
    print("\n" + "=" * 40)
    print("FINAL MODEL PARAMETERS")
    print("=" * 40)
    print(f"W1 (Input -> Hidden):\n{W1}\n")
    print(f"b1 (Hidden Biases):\n{b1}\n")
    print(f"W2 (Hidden -> Output):\n{W2}\n")
    print(f"b2 (Output Biases):\n{b2}")
    print("=" * 40)

if __name__ == "__main__":
    run()